""" Version information"""
VERSION = "2.0"
