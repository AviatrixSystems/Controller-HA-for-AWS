""" Version information"""
VERSION = "1.6"
