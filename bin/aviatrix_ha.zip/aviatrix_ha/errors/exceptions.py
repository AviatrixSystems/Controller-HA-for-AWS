""" Module to hold all errors"""


class AvxError(Exception):
    """Error class for Aviatrix exceptions"""
