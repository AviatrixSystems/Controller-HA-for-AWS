""" Version information"""

VERSION = "2.04"
