MASK = lambda input: input[0:5] + '*' * 15 if isinstance(input, str) else ''
